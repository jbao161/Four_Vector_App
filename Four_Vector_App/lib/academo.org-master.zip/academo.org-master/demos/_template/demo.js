var demo = new Demo({
	ui: {
		slider: {
			title: "Slider",
			value: 10,
			range: [1, 20],
			resolution: 0.01
		},
		checkbox: {
			title: "Checkbox",
			value: true
		},
		button: {
			title: "Button",
			type: "button"
		}
	},

	init: function(){

	},

	update: function(e){

	}
});